package Listeners;

public interface ModelListenable {

}
